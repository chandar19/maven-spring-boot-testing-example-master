package example.spring.bootapp.controller;

import org.junit.Assert;
import org.junit.Test;

public class IT_ExampleIntegrationTest
{
    @Test
    public void integrationTestIt()
    {
        Assert.assertTrue(true);
    }
}
