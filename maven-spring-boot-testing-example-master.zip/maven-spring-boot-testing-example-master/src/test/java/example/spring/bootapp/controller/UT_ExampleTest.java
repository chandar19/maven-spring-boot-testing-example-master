package example.spring.bootapp.controller;

import org.junit.Assert;
import org.junit.Test;

public class UT_ExampleTest
{
    @Test
    public void testIt()
    {
        Assert.assertTrue(true);
    }
}
